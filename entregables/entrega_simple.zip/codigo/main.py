"""Punto de entrada del solver A* (Robot Amazon).

Ejecutar desde este directorio:

    python main.py                    # corrida con traza compacta
    python main.py --completa         # 323 iteraciones detalladas

Ejecutar tests:
    python -m unittest discover -s tests
"""
from solver.main import main

if __name__ == "__main__":
    raise SystemExit(main())
